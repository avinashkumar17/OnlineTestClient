package com.example.demo;

public interface DaoInter {

	void innsertRecords(AdminLogin adminLogin);

	
}
