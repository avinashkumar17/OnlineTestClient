package com.example.demo;

public interface SeviceInter {

	void insertData(AdminLogin adminLogin);

}
