package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("impl")
public class RepoImpl  implements DaoInter{

	@Autowired   SpringJpa jpa;

	@Override
	public void innsertRecords(AdminLogin adminLogin) {
		// TODO Auto-generated method stub
		jpa.delete(adminLogin);
		throw new RuntimeException();
		
	}
	

}
