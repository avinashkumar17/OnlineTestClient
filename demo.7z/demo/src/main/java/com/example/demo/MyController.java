package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

	@Autowired SeviceInter serv;
	
	@RequestMapping(value="index",method=RequestMethod.GET)
	public @ResponseBody  String ind() {
		try {
		serv.insertData(new AdminLogin(1,"test1","test1"));
		}catch(Exception e)
		{
			return "failure";
		}
		return "success";
	}
	
}
