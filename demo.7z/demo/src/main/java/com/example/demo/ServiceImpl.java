package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ServiceImpl implements SeviceInter{

	@Autowired DaoInter impl;

	@Transactional(rollbackFor=Exception.class,propagation=Propagation.REQUIRED)
	@Override
	public void insertData(AdminLogin adminLogin) {
		// TODO Auto-generated method stub
		impl.innsertRecords(adminLogin);	
	}
	 

}
